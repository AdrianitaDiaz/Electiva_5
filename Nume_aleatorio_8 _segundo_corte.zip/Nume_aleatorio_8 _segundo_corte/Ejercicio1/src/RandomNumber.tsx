import { useState } from 'react';

const RandomNumber = () => {
  const [randomNumber, setRandomNumber] = useState<number | null>(null);

  const generateRandom = () => {
    const number = Math.floor(Math.random() * 100) + 1; // Entre 1 y 100
    setRandomNumber(number);
  };

  return (
    <div className="flex flex-col items-center gap-4 p-4">
      <h3 className="text-xl font-bold">Número Aleatorio</h3>
      <p className="text-2xl">
        {randomNumber !== null ? randomNumber : "Presiona el botón"}
      </p>
      <button
        onClick={generateRandom}
        className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 transition"
      >
        Generar número
      </button>
    </div>
  );
};

export default RandomNumber;
