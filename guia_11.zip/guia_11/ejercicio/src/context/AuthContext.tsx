import { createContext, useEffect, useState } from "react";

// Enums
export enum AuthStatus {
  checking,
  authenticated,
  unauthenticated,
}

export enum UserRole {
  Admin = "admin",
  Editor = "editor",
  Viewer = "viewer",
}

// Interfaces
interface User {
  role: UserRole;
  name: string;
  email: string;
}

interface AuthState {
  status: AuthStatus;
  isChecking: boolean;
  token?: string;
  user?: User;
  loginWithEmailPassword: () => void;
  logout: () => void;
}

// Crear contexto
export const AuthContext = createContext({} as AuthState);

// Provider
export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [status, setStatus] = useState<AuthStatus>(AuthStatus.checking);
  const [user, setUser] = useState<User>();

  useEffect(() => {
    const timer = setTimeout(() => {
      setStatus(AuthStatus.unauthenticated);
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  const loginWithEmailPassword = () => {
    setUser({
      role: UserRole.Admin,
      name: "Julio",
      email: "x@gmail.com",
    });
    setStatus(AuthStatus.authenticated);
  };

  const logout = () => {
    setUser(undefined);
    setStatus(AuthStatus.unauthenticated);
  };

  return (
    <AuthContext.Provider
      value={{
        status,
        isChecking: status === AuthStatus.checking,
        token: "abc123",
        user,
        loginWithEmailPassword,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
