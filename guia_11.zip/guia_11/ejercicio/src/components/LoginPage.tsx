import { useAuthContext } from "../context/useAuthContext";

export const LoginPage = () => {
  const { isChecking, loginWithEmailPassword, user, logout } = useAuthContext();

  if (isChecking) {
    return <p>🔄 Verificando usuario...</p>;
  }

  if (user) {
    return (
      <div style={{ textAlign: "center" }}>
        <h2>👋 Bienvenido, {user.name}</h2>
        <p>📧 Correo: {user.email}</p>
        <p>🎓 Rol: {user.role}</p>
        <button onClick={logout}>Salir</button>
      </div>
    );
  }

  return (
    <div style={{ textAlign: "center" }}>
      <h2>Iniciar sesión</h2>
      <button onClick={loginWithEmailPassword}>Ingresar</button>
    </div>
  );
};
