import { AuthProvider } from "./context/AuthContext";
import { LoginPage } from "./components/LoginPage";

function App() {
  return (
    <AuthProvider>
      <LoginPage />
    </AuthProvider>
  );
}

export default App;
