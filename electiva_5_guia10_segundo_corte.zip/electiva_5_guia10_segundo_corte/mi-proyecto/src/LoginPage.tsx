import { useAuthContext } from './AuthContext';


export const LoginPage = () => {
    const { hola } = useAuthContext();

    return (
        <div>
            <h3>Login Page</h3>
            <span>{hola}</span>
        </div>
    );
};
