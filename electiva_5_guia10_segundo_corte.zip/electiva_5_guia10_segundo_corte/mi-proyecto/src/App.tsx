import './App.css';
import { AuthProvider } from './AuthContext';
import { LoginPage } from './LoginPage';


function App() {
  return (
    <AuthProvider>
      <LoginPage />
    </AuthProvider>
  );
}

export default App;
