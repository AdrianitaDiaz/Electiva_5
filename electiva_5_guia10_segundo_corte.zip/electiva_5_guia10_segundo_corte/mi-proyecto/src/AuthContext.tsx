import { createContext, PropsWithChildren, useContext } from "react";

// Paso 1: Definimos la forma del estado del contexto
interface AuthState {
  hola: string;
}

// Paso 2: Creamos el contexto con valor inicial vacío pero tipado
export const AuthContext = createContext({} as AuthState);

// Paso 3: Hook personalizado para acceder fácilmente al contexto
export const useAuthContext = () => useContext(AuthContext);

// Paso 4: Componente proveedor que envuelve a los hijos
export const AuthProvider = ({ children }: PropsWithChildren) => {
  return (
    <AuthContext.Provider value={{ hola: "Hola desde el contexto!" }}>
      {children}
    </AuthContext.Provider>
  );
};
